class ThemeUrlMappings {

	static mappings = {
		"/theme"(view:"/theme")
	}
}
